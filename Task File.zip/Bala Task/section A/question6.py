def longestPalinSub(st):
    # Stores the length of
    # str
    N = len(st)

    # Store the count of
    # occurrence of each
    # character
    hash1 = [0] * 256

    # Traverse the string,
    # str
    for i in range(N):
        # Count occurrence of
        # each character
        hash1[ord(st[i])] += 1

    # Store the left half of the
    # longest palindromic substring
    res1 = ""

    # Store the right half of the
    # longest palindromic substring
    res2 = ""

    # Traverse the array, hash[]
    for i in range(256):

        # Append half of the
        # characters  to res1
        for j in range(hash1[i] // 2):
            res1 += chr(i)

        # Append half of the
        # characters  to res2
        for j in range((hash1[i] + 1) // 2,
                       hash1[i]):
            res2 += chr(i)

    # reverse string res2 to make
    # res1 + res2 palindrome
    p = list(res2)
    p.reverse()
    res2 = ''.join(p)

    # Store the remaining characters
    res3 = ""

    # Check If any odd character
    # appended to the middle of
    # the resultant string or not
    f = False

    # Append all the character which
    # occurs odd number of times
    for i in range(256):

        # If count of occurrence
        # of characters is odd
        if (hash1[i] % 2):
            if (not f):
                res1 += chr(i)
                f = True
            else:
                res3 += chr(i)

    return (res1 + res2)


# Driver Code
if __name__ == "__main__":
    st = str(input("Enter the string : "))
    print(longestPalinSub(st))