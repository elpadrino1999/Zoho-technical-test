string = str(input("Enter the string: "))
print("The distinct words are : " + ' '.join(dict.fromkeys(string.split())))