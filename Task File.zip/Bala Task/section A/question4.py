# getting input
rows = int(input("Enter the number = "))

# Creating first half of square
for i in range(1, rows + 1):
    # printing left part of the block
    for j in range(1, rows + 1):
        if i < j:
            print(rows - i + 1, end = ' ')
        else:
            print(rows - j + 1, end = ' ')
    # printing right part of the block
    for k in range(rows - 1, 0, - 1):
        if i < k:
            print(rows - i + 1, end = ' ')
        else:
            print(rows - k + 1, end = ' ')
    print()

# Creating second half of square
for i in range(rows - 1, 0, -1):
    # printing left part of the block
    for j in range(1, rows + 1):
        if i < j:
            print(rows - i + 1, end = ' ')
        else:
            print(rows - j + 1, end = ' ')
    # printing right part of the block
    for k in range(rows - 1, 0, - 1):
        if i < k:
            print(rows - i + 1, end = ' ')
        else:
            print(rows - k + 1, end = ' ')
    print()

