n = int(input("please enter number of string"))
# defining empy list:
lst = []
# Taking multiple inputs based on n:
for i in range(n):
    t = str(input("please enter string " + str(i+1)))
# sort the string
    x = ''.join(sorted(t, reverse=True))
# append in the list
    lst.append(x)
# print the results
for i in range(len(lst)):
    print("string " + str(i+1) + "=" + lst[i])
